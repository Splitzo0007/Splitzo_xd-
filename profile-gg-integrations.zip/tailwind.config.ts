import type { Config } from 'tailwindcss';
export default { content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { ink: '#08070d', panel: '#12101b', violet: '#9b6cff' }, boxShadow: { glow: '0 0 60px rgba(139,92,246,.18)' } } }, plugins: [] } satisfies Config;

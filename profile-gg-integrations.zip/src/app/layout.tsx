import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'profile.gg — Your identity, your space', description: 'Create a profile that represents you.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }

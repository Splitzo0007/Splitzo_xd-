export type Provider = 'discord'|'spotify'|'steam'|'youtube'|'twitch'|'github';
export const providers: {id:Provider;name:string;description:string;scopes:string;mode:'oauth'|'api-key'|'manual';features:string[]}[] = [
 {id:'discord',name:'Discord',description:'Account identity, avatar, and presence where authorized.',scopes:'identify, activities.read',mode:'oauth',features:['Account','Avatar','Activity/status*']},
 {id:'spotify',name:'Spotify',description:'Currently playing track and public playlists.',scopes:'user-read-currently-playing user-read-playback-state playlist-read-private',mode:'oauth',features:['Now playing','Playlists']},
 {id:'steam',name:'Steam',description:'Public profile and recently played games.',scopes:'Steam Web API key + SteamID',mode:'api-key',features:['Profile','Games']},
 {id:'youtube',name:'YouTube',description:'Channel information and public videos.',scopes:'youtube.readonly',mode:'oauth',features:['Channel','Videos']},
 {id:'twitch',name:'Twitch',description:'Channel information and live stream status.',scopes:'user:read:email (optional)',mode:'oauth',features:['Channel','Live status']},
 {id:'github',name:'GitHub',description:'Public repositories and contribution/activity links.',scopes:'read:user public_repo',mode:'oauth',features:['Repositories','Activity']},
];
export const providerEnv: Record<Provider,{id:string;secret:string;callback:string}> = {
 discord:{id:'DISCORD_CLIENT_ID',secret:'DISCORD_CLIENT_SECRET',callback:'discord'},
 spotify:{id:'SPOTIFY_CLIENT_ID',secret:'SPOTIFY_CLIENT_SECRET',callback:'spotify'},
 youtube:{id:'GOOGLE_CLIENT_ID',secret:'GOOGLE_CLIENT_SECRET',callback:'youtube'},
 twitch:{id:'TWITCH_CLIENT_ID',secret:'TWITCH_CLIENT_SECRET',callback:'twitch'},
 github:{id:'GITHUB_CLIENT_ID',secret:'GITHUB_CLIENT_SECRET',callback:'github'},
 steam:{id:'STEAM_WEB_API_KEY',secret:'',callback:'steam'},
};

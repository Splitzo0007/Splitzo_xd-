create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9_]{3,24}$'),
  display_name text not null default '', bio text not null default '',
  avatar_url text, background_url text, accent_color text not null default '#9b6cff',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.social_links (
  id uuid primary key default gen_random_uuid(), profile_id uuid not null references public.profiles(id) on delete cascade,
  label text not null, url text not null, sort_order int not null default 0
);
create table if not exists public.profile_views (
  id bigint generated always as identity primary key, profile_id uuid not null references public.profiles(id) on delete cascade,
  viewed_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.social_links enable row level security;
alter table public.profile_views enable row level security;
create policy "profiles are public to read" on public.profiles for select using (true);
create policy "users manage own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "social links public read" on public.social_links for select using (true);
create policy "users manage own links" on public.social_links for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);
create policy "owners read views" on public.profile_views for select using (exists(select 1 from public.profiles p where p.id = profile_id and p.id = auth.uid()));
-- Add server-side view tracking with a restricted RPC or Edge Function before launch.


-- OAuth connections: tokens must be encrypted by trusted server code before insert.
create table if not exists public.connected_accounts (
 id uuid primary key default gen_random_uuid(),
 profile_id uuid not null references public.profiles(id) on delete cascade,
 provider text not null check (provider in ('discord','spotify','steam','youtube','twitch','github')),
 provider_user_id text,
 display_name text,
 avatar_url text,
 encrypted_access_token text,
 encrypted_refresh_token text,
 token_expires_at timestamptz,
 scopes text[] not null default '{}',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(profile_id,provider)
);
alter table public.connected_accounts enable row level security;
-- Do not add public SELECT policies for this table: OAuth credentials are private.
create policy "owners manage connected accounts" on public.connected_accounts
 for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create table if not exists public.profile_widgets (
 id uuid primary key default gen_random_uuid(),
 profile_id uuid not null references public.profiles(id) on delete cascade,
 provider text not null,
 widget_type text not null,
 enabled boolean not null default true,
 config jsonb not null default '{}',
 sort_order int not null default 0,
 created_at timestamptz not null default now()
);
alter table public.profile_widgets enable row level security;
create policy "public can read enabled widgets" on public.profile_widgets for select using (enabled = true);
create policy "owners manage widgets" on public.profile_widgets for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create table if not exists public.custom_links (
 id uuid primary key default gen_random_uuid(),
 profile_id uuid not null references public.profiles(id) on delete cascade,
 label text not null,
 url text not null,
 sort_order int not null default 0,
 created_at timestamptz not null default now()
);
alter table public.custom_links enable row level security;
create policy "public can read custom links" on public.custom_links for select using (true);
create policy "owners manage custom links" on public.custom_links for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

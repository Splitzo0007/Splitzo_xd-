# profile.gg

A dark black + purple profile platform starter built with Next.js App Router, TypeScript, Tailwind CSS, and Supabase.

## Included
- Landing page with dark purple visual identity
- Public profile route: `/[username]`
- Dashboard UI: `/dashboard`
- Sign-in/sign-up page UI: `/login`
- Supabase browser/server client helpers
- SQL schema for profiles, social links, and page views
- Basic profile editing API route
- Responsive layout

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local` and fill in your Supabase URL and anon key.
3. Run:
   ```bash
   npm install
   npm run dev
   ```
4. Open http://localhost:3000

## Supabase setup
- Create a Supabase project.
- Run `supabase/schema.sql` in the Supabase SQL editor.
- Enable Email auth in Supabase Authentication.
- Add your Supabase project URL and anon key to `.env.local`.

## Domain
This starter does not register or connect `profile.gg`. You will need to purchase/own the domain, deploy the app (e.g. Vercel), and configure DNS. Never put a Supabase service-role key in client-side code.

## Before public launch
Add email verification, rate limiting, abuse reporting/moderation, username reservation, CAPTCHA, privacy policy, terms, backups, and robust server-side validation. The included UI is a foundation, not a production-audited service.

## App integrations foundation
The integrations center is at `/dashboard/integrations`. It includes Discord, Spotify, Steam, YouTube, Twitch, GitHub, Instagram manual-link fallback, and arbitrary custom links.

Provider OAuth routes start at `/api/integrations/[provider]/connect` and validate a short-lived, HTTP-only state cookie on callback. Add the exact callback URLs shown by your deployment to each provider developer console. Set the provider environment variables from `.env.example`.

**Important integration status:** OAuth initiation/state validation and a server-side Steam profile proxy are scaffolded. The callback currently does not exchange or persist OAuth tokens. Before production, implement provider-specific token exchange, PKCE where required, encrypted token storage using `INTEGRATION_TOKEN_ENCRYPTION_KEY`, refresh-token rotation, disconnect/revoke, authenticated ownership checks, webhook/polling jobs, and provider-specific API adapters. Never expose provider client secrets or tokens in browser code. Instagram is a manual URL fallback because general personal-account access is restricted; supported Instagram API access is limited to eligible professional accounts and permissions. Discord presence is not guaranteed for arbitrary users. Follow each provider's current API terms, scopes, rate limits, and display rules.
